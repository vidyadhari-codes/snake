import React, { useState } from 'react';
import { SnakeGame } from './components/SnakeGame';
import { MusicPlayer } from './components/MusicPlayer';
import { GameState } from './types';
import { TerminalSquare } from 'lucide-react';

const App: React.FC = () => {
    const [score, setScore] = useState(0);
    const [highScore, setHighScore] = useState(0);
    const [gameState, setGameState] = useState<GameState>(GameState.IDLE);
    const [isMusicPlaying, setIsMusicPlaying] = useState(false);

    const handleScoreChange = (newScore: number) => {
        setScore(newScore);
        if (newScore > highScore) {
            setHighScore(newScore);
        }
    };

    const handleGameOver = () => {
        // Additional game over logic if needed
    };

    return (
        <div className="min-h-screen bg-sys-black text-sys-cyan font-sys selection:bg-sys-magenta selection:text-sys-black flex flex-col relative z-10 animate-tear">
            
            {/* Header */}
            <header className="w-full p-4 md:p-6 flex flex-col md:flex-row justify-between items-start md:items-center border-b-4 border-sys-magenta bg-sys-black">
                <div className="flex items-center gap-4 mb-4 md:mb-0">
                    <TerminalSquare className="w-10 h-10 text-sys-magenta animate-pulse" strokeWidth={1.5} />
                    <div>
                        <h1 className="text-3xl md:text-5xl font-bold tracking-widest rgb-split glitch-text-raw" data-text="SYS.OP.TERMINAL">
                            SYS.OP.TERMINAL
                        </h1>
                        <p className="text-sys-white text-sm tracking-widest">v.9.9.9 // UNAUTHORIZED_ACCESS</p>
                    </div>
                </div>
                
                {/* Score Display */}
                <div className="flex gap-8 border-2 border-sys-cyan p-2 bg-sys-gray">
                    <div className="flex flex-col items-end">
                        <span className="text-sm text-sys-magenta tracking-widest">>> DATA_YIELD</span>
                        <span 
                            className="text-4xl font-bold text-sys-cyan rgb-split" 
                        >
                            {score.toString().padStart(4, '0')}
                        </span>
                    </div>
                    <div className="flex flex-col items-end">
                        <span className="text-sm text-sys-magenta tracking-widest">>> MAX_CAPACITY</span>
                        <span 
                            className="text-4xl font-bold text-sys-white rgb-split-magenta" 
                        >
                            {highScore.toString().padStart(4, '0')}
                        </span>
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <main className="flex-1 flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-12 p-4 md:p-8">
                
                {/* Left/Top: Game Area */}
                <div className="flex flex-col items-center w-full lg:w-auto">
                    <div className="mb-2 w-full flex justify-between text-sys-magenta text-lg border-b-2 border-sys-magenta">
                        <span>[PROCESS: SNAKE.EXE]</span>
                        <span className="animate-blink">_</span>
                    </div>
                    <SnakeGame 
                        onScoreChange={handleScoreChange}
                        onGameOver={handleGameOver}
                        gameState={gameState}
                        setGameState={setGameState}
                    />
                </div>

                {/* Right/Bottom: Music Player & Info */}
                <div className="flex flex-col items-center lg:items-start gap-8 w-full max-w-md">
                    <div className="w-full">
                        <div className="mb-2 w-full flex justify-between text-sys-cyan text-lg border-b-2 border-sys-cyan">
                            <span>[PROCESS: AUDIO_STREAM]</span>
                            <span className="animate-blink">_</span>
                        </div>
                        <MusicPlayer onPlayStateChange={setIsMusicPlaying} />
                    </div>
                    
                    {/* Status Panel */}
                    <div className="w-full bg-sys-black sys-border-magenta p-4 text-lg">
                        <h3 className="text-sys-white mb-4 border-b-2 border-sys-gray pb-2 rgb-split-magenta">>> SYS_DIAGNOSTICS</h3>
                        <ul className="space-y-2">
                            <li className="flex justify-between">
                                <span className="text-sys-magenta">AUDIO_LINK:</span>
                                <span className={isMusicPlaying ? 'text-sys-cyan animate-pulse' : 'text-sys-gray'}>
                                    [{isMusicPlaying ? 'ACTIVE' : 'OFFLINE'}]
                                </span>
                            </li>
                            <li className="flex justify-between">
                                <span className="text-sys-magenta">CORE_STATE:</span>
                                <span className={gameState === GameState.PLAYING ? 'text-sys-cyan' : 'text-sys-white rgb-split'}>
                                    [{gameState}]
                                </span>
                            </li>
                            <li className="flex justify-between">
                                <span className="text-sys-magenta">INPUT_METHOD:</span>
                                <span className="text-sys-cyan">[KEYBOARD_OVERRIDE]</span>
                            </li>
                        </ul>
                    </div>
                </div>

            </main>
        </div>
    );
};

export default App;
