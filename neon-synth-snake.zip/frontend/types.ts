export interface Point {
    x: number;
    y: number;
}

export interface Track {
    id: string;
    title: string;
    artist: string;
    url: string;
    colorClass: string;
    neonClass: string;
}

export enum GameState {
    IDLE = 'IDLE',
    PLAYING = 'PLAYING',
    GAME_OVER = 'GAME_OVER',
    PAUSED = 'PAUSED'
}
