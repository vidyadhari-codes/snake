import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Point, GameState } from '../types';
import { GRID_SIZE, CELL_SIZE, CANVAS_SIZE, INITIAL_SPEED, SPEED_INCREMENT, MIN_SPEED } from '../constants';

interface SnakeGameProps {
    onScoreChange: (score: number) => void;
    onGameOver: () => void;
    gameState: GameState;
    setGameState: (state: GameState) => void;
}

export const SnakeGame: React.FC<SnakeGameProps> = ({ onScoreChange, onGameOver, gameState, setGameState }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    
    const snakeRef = useRef<Point[]>([{ x: 10, y: 10 }]);
    const dirRef = useRef<Point>({ x: 1, y: 0 });
    const nextDirRef = useRef<Point>({ x: 1, y: 0 });
    const foodRef = useRef<Point>({ x: 15, y: 10 });
    const scoreRef = useRef<number>(0);
    const speedRef = useRef<number>(INITIAL_SPEED);
    const lastRenderTimeRef = useRef<number>(0);
    const requestRef = useRef<number>();

    const generateFood = useCallback((): Point => {
        let newFood: Point;
        let isOnSnake = true;
        while (isOnSnake) {
            newFood = {
                x: Math.floor(Math.random() * GRID_SIZE),
                y: Math.floor(Math.random() * GRID_SIZE)
            };
            // eslint-disable-next-line no-loop-func
            isOnSnake = snakeRef.current.some(segment => segment.x === newFood.x && segment.y === newFood.y);
        }
        return newFood!;
    }, []);

    const resetGame = useCallback(() => {
        snakeRef.current = [{ x: 10, y: 10 }];
        dirRef.current = { x: 1, y: 0 };
        nextDirRef.current = { x: 1, y: 0 };
        scoreRef.current = 0;
        speedRef.current = INITIAL_SPEED;
        foodRef.current = generateFood();
        onScoreChange(0);
    }, [generateFood, onScoreChange]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)) {
                e.preventDefault();
            }

            if (gameState !== GameState.PLAYING) {
                if (e.key === ' ' && (gameState === GameState.IDLE || gameState === GameState.GAME_OVER)) {
                    if (gameState === GameState.GAME_OVER) resetGame();
                    setGameState(GameState.PLAYING);
                }
                return;
            }

            const currentDir = dirRef.current;
            switch (e.key) {
                case 'ArrowUp':
                case 'w':
                case 'W':
                    if (currentDir.y !== 1) nextDirRef.current = { x: 0, y: -1 };
                    break;
                case 'ArrowDown':
                case 's':
                case 'S':
                    if (currentDir.y !== -1) nextDirRef.current = { x: 0, y: 1 };
                    break;
                case 'ArrowLeft':
                case 'a':
                case 'A':
                    if (currentDir.x !== 1) nextDirRef.current = { x: -1, y: 0 };
                    break;
                case 'ArrowRight':
                case 'd':
                case 'D':
                    if (currentDir.x !== -1) nextDirRef.current = { x: 1, y: 0 };
                    break;
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [gameState, setGameState, resetGame]);

    const update = useCallback(() => {
        const snake = [...snakeRef.current];
        dirRef.current = nextDirRef.current;
        const dir = dirRef.current;
        const head = { ...snake[0] };

        head.x += dir.x;
        head.y += dir.y;

        if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
            setGameState(GameState.GAME_OVER);
            onGameOver();
            return;
        }

        if (snake.some(segment => segment.x === head.x && segment.y === head.y)) {
            setGameState(GameState.GAME_OVER);
            onGameOver();
            return;
        }

        snake.unshift(head);

        if (head.x === foodRef.current.x && head.y === foodRef.current.y) {
            scoreRef.current += 10;
            onScoreChange(scoreRef.current);
            foodRef.current = generateFood();
            speedRef.current = Math.max(MIN_SPEED, speedRef.current - SPEED_INCREMENT);
        } else {
            snake.pop();
        }

        snakeRef.current = snake;
    }, [generateFood, onGameOver, onScoreChange, setGameState]);

    const draw = useCallback(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Clear canvas with slight transparency for a glitchy trail
        ctx.fillStyle = 'rgba(5, 5, 5, 0.3)'; 
        ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

        // Draw Grid (Harsh lines)
        ctx.strokeStyle = '#1A1A1A';
        ctx.lineWidth = 1;
        for (let i = 0; i <= CANVAS_SIZE; i += CELL_SIZE) {
            ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, CANVAS_SIZE); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(CANVAS_SIZE, i); ctx.stroke();
        }

        // Draw Food (Raw Magenta Square)
        const food = foodRef.current;
        ctx.fillStyle = '#FF00FF';
        // Occasional glitch offset for food
        const glitchOffset = Math.random() > 0.9 ? (Math.random() > 0.5 ? 2 : -2) : 0;
        ctx.fillRect(
            food.x * CELL_SIZE + glitchOffset, 
            food.y * CELL_SIZE, 
            CELL_SIZE, 
            CELL_SIZE
        );

        // Draw Snake (Raw Cyan Squares)
        const snake = snakeRef.current;
        snake.forEach((segment, index) => {
            ctx.fillStyle = index === 0 ? '#FFFFFF' : '#00FFFF';
            
            // Add random static/glitch to body segments
            const isGlitching = index !== 0 && Math.random() > 0.8;
            if (isGlitching) {
                ctx.fillStyle = '#FF00FF'; // Flash magenta
            }

            ctx.fillRect(
                segment.x * CELL_SIZE + 1, 
                segment.y * CELL_SIZE + 1, 
                CELL_SIZE - 2, 
                CELL_SIZE - 2
            );
        });

    }, []);

    const gameLoop = useCallback((currentTime: number) => {
        if (gameState !== GameState.PLAYING) {
            draw();
            return;
        }

        requestRef.current = requestAnimationFrame(gameLoop);

        const secondsSinceLastRender = (currentTime - lastRenderTimeRef.current);
        if (secondsSinceLastRender < speedRef.current) return;

        lastRenderTimeRef.current = currentTime;
        update();
        draw();
    }, [gameState, update, draw]);

    useEffect(() => {
        requestRef.current = requestAnimationFrame(gameLoop);
        return () => {
            if (requestRef.current) cancelAnimationFrame(requestRef.current);
        };
    }, [gameLoop]);

    useEffect(() => {
        draw();
    }, [draw]);

    return (
        <div className="relative sys-border bg-sys-black">
            <canvas
                ref={canvasRef}
                width={CANVAS_SIZE}
                height={CANVAS_SIZE}
                className="block"
            />

            {/* Overlays */}
            {gameState === GameState.IDLE && (
                <div className="absolute inset-0 bg-sys-black/80 flex flex-col items-center justify-center text-center p-6 border-4 border-sys-cyan m-2">
                    <h2 className="text-5xl font-bold text-sys-cyan mb-4 glitch-text-raw" data-text="INITIALIZE_SEQUENCE">INITIALIZE_SEQUENCE</h2>
                    <p className="text-sys-white text-xl mb-8">> AWAITING_INPUT [ARROWS/WASD]</p>
                    <button 
                        onClick={() => setGameState(GameState.PLAYING)}
                        className="px-8 py-3 bg-sys-cyan text-sys-black text-2xl font-bold hover:bg-sys-magenta hover:text-sys-white transition-none"
                    >
                        [ EXECUTE ]
                    </button>
                </div>
            )}

            {gameState === GameState.GAME_OVER && (
                <div className="absolute inset-0 bg-sys-black/90 flex flex-col items-center justify-center text-center p-6 border-4 border-sys-magenta m-2">
                    <h2 className="text-6xl font-bold text-sys-magenta mb-2 glitch-text-raw" data-text="FATAL_EXCEPTION">FATAL_EXCEPTION</h2>
                    <p className="text-3xl text-sys-white mb-8">YIELD: <span className="text-sys-cyan">[{scoreRef.current}]</span></p>
                    <button 
                        onClick={() => {
                            resetGame();
                            setGameState(GameState.PLAYING);
                        }}
                        className="px-8 py-3 bg-sys-magenta text-sys-black text-2xl font-bold hover:bg-sys-cyan hover:text-sys-black transition-none"
                    >
                        [ REBOOT_SYSTEM ]
                    </button>
                </div>
            )}
        </div>
    );
};
