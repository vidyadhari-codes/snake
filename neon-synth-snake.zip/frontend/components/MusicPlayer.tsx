import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, Disc } from 'lucide-react';
import { TRACKS } from '../constants';

interface MusicPlayerProps {
    onPlayStateChange?: (isPlaying: boolean) => void;
}

export const MusicPlayer: React.FC<MusicPlayerProps> = ({ onPlayStateChange }) => {
    const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [volume, setVolume] = useState(0.5);
    const [isMuted, setIsMuted] = useState(false);
    const [progress, setProgress] = useState(0);
    
    const audioRef = useRef<HTMLAudioElement>(null);
    const currentTrack = TRACKS[currentTrackIndex];

    useEffect(() => {
        if (audioRef.current) {
            audioRef.current.volume = isMuted ? 0 : volume;
        }
    }, [volume, isMuted]);

    useEffect(() => {
        if (onPlayStateChange) {
            onPlayStateChange(isPlaying);
        }
    }, [isPlaying, onPlayStateChange]);

    const togglePlay = () => {
        if (audioRef.current) {
            if (isPlaying) {
                audioRef.current.pause();
            } else {
                audioRef.current.play().catch(e => console.error("Playback failed:", e));
            }
            setIsPlaying(!isPlaying);
        }
    };

    const handleNext = () => {
        setCurrentTrackIndex((prev) => (prev + 1) % TRACKS.length);
        setIsPlaying(true);
    };

    const handlePrev = () => {
        setCurrentTrackIndex((prev) => (prev - 1 + TRACKS.length) % TRACKS.length);
        setIsPlaying(true);
    };

    const handleTimeUpdate = () => {
        if (audioRef.current) {
            const current = audioRef.current.currentTime;
            const duration = audioRef.current.duration;
            if (duration) {
                setProgress((current / duration) * 100);
            }
        }
    };

    const handleTrackEnded = () => {
        handleNext();
    };

    useEffect(() => {
        if (audioRef.current && isPlaying) {
            audioRef.current.play().catch(e => {
                console.error("Autoplay prevented on track change", e);
                setIsPlaying(false);
            });
        }
    }, [currentTrackIndex]);

    return (
        <div className="w-full bg-sys-black sys-border p-6 flex flex-col gap-6 relative">
            
            <audio
                ref={audioRef}
                src={currentTrack.url}
                onTimeUpdate={handleTimeUpdate}
                onEnded={handleTrackEnded}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
            />

            {/* Header */}
            <div className="flex justify-between items-center border-b-2 border-sys-gray pb-2">
                <div className="flex items-center gap-2 text-sys-magenta">
                    <Disc className={`w-6 h-6 ${isPlaying ? 'animate-spin' : ''}`} strokeWidth={1.5} />
                    <span className="text-lg tracking-widest">>> STREAM_ACTIVE</span>
                </div>
                
                {/* Blocky Visualizer */}
                <div className="flex items-end gap-1 h-6">
                    {[1,2,3,4,5].map((i) => (
                        <div 
                            key={i}
                            className="w-3 bg-sys-cyan" 
                            style={{ 
                                height: isPlaying ? `${Math.random() * 100}%` : '4px',
                                transition: 'height 0.1s steps(3)'
                            }}
                        ></div>
                    ))}
                </div>
            </div>

            {/* Track Info */}
            <div className="text-left">
                <h3 className={`text-3xl font-bold truncate ${currentTrack.neonClass} ${currentTrack.colorClass}`}>
                    {currentTrack.title}
                </h3>
                <p className="text-xl text-sys-white mt-1">SRC: {currentTrack.artist}</p>
            </div>

            {/* Progress Bar (Blocky) */}
            <div className="w-full h-4 bg-sys-gray border-2 border-sys-cyan relative">
                <div 
                    className={`h-full bg-sys-magenta`}
                    style={{ width: `${progress}%`, transition: 'width 0.2s steps(10)' }}
                ></div>
            </div>

            {/* Controls */}
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 w-1/3">
                    <button 
                        onClick={() => setIsMuted(!isMuted)}
                        className="text-sys-cyan hover:text-sys-magenta hover:bg-sys-cyan p-1 transition-none"
                    >
                        {isMuted || volume === 0 ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
                    </button>
                    <input 
                        type="range" 
                        min="0" 
                        max="1" 
                        step="0.1" 
                        value={isMuted ? 0 : volume}
                        onChange={(e) => {
                            setVolume(parseFloat(e.target.value));
                            if (isMuted) setIsMuted(false);
                        }}
                        className="w-full h-2 bg-sys-gray appearance-none cursor-pointer accent-sys-magenta"
                        style={{ border: '1px solid #00FFFF' }}
                    />
                </div>

                <div className="flex items-center gap-2 justify-end w-2/3">
                    <button 
                        onClick={handlePrev}
                        className="p-2 border-2 border-sys-cyan text-sys-cyan hover:bg-sys-cyan hover:text-sys-black transition-none"
                    >
                        <SkipBack className="w-6 h-6" />
                    </button>
                    
                    <button 
                        onClick={togglePlay}
                        className={`p-2 border-2 transition-none ${
                            isPlaying 
                            ? 'border-sys-magenta text-sys-magenta hover:bg-sys-magenta hover:text-sys-black' 
                            : 'border-sys-cyan text-sys-cyan hover:bg-sys-cyan hover:text-sys-black'
                        }`}
                    >
                        {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
                    </button>
                    
                    <button 
                        onClick={handleNext}
                        className="p-2 border-2 border-sys-cyan text-sys-cyan hover:bg-sys-cyan hover:text-sys-black transition-none"
                    >
                        <SkipForward className="w-6 h-6" />
                    </button>
                </div>
            </div>
        </div>
    );
};
