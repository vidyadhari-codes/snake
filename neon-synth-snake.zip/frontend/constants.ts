import { Track } from './types';

export const GRID_SIZE = 20;
export const CELL_SIZE = 20; // pixels
export const CANVAS_SIZE = GRID_SIZE * CELL_SIZE;
export const INITIAL_SPEED = 70; 
export const SPEED_INCREMENT = 2;
export const MIN_SPEED = 30; 

export const TRACKS: Track[] = [
    {
        id: 'trk-01',
        title: 'DATA_CORRUPTION.WAV',
        artist: 'SYS_ADMIN',
        url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
        colorClass: 'text-sys-cyan',
        neonClass: 'rgb-split'
    },
    {
        id: 'trk-02',
        title: 'MEMORY_LEAK.MP3',
        artist: 'UNKNOWN_PROCESS',
        url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
        colorClass: 'text-sys-magenta',
        neonClass: 'rgb-split-magenta'
    },
    {
        id: 'trk-03',
        title: 'BUFFER_OVERFLOW.FLAC',
        artist: 'KERNEL_PANIC',
        url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
        colorClass: 'text-sys-cyan',
        neonClass: 'rgb-split'
    }
];
